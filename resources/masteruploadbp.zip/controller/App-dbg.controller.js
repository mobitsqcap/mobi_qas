sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("masteruploadbp.controller.App", {
      onInit() {
      }
  });
});